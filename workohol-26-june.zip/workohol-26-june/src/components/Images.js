
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Images.css';
import mobilemain from '../images/mobilemainimg.png';
import webmainimg from '../images/webmainimg.png';
import webtitlemainims from '../images/webmaintitleimg.png';

const Images = () => {
  return (
    <div className="background-blue">
      <div className="container">
        <div className="row d-none d-md-flex justify-content-center mt-5">
          <div className="col-md-5 mt-5">
            <img
              src={webtitlemainims}
              alt="wokcoholimage1"
              className="img-fluid center-img"
            />
          </div>
          {/* <div>
            <h1 style={{fontSize:"70px", fontFamily:"Poppins", fontWeight:"700px",color:}}>Find the World’s Best
            </h1>
          <p style={{fontSize:'19px' , fontWeight:"500" , textAlign:"left", fontFamily:"inter", color:"black"}}>Explore thousands of job listings, from entry-level positions to executive <br/>roles. Find your next career move or discover the perfect candidate <br/>for  your company.</p>
          </div> */}
          <div className="col-md-5">
            <img
              src={webmainimg}
              alt="workcoholimage2"
              className="img-fluid center-img"
            />
          </div>
        </div>
        <div className="row d-flex d-md-none justify-content-center mt-5">
          <div className="col-12">
            <img
              src={mobilemain}
              alt="workoholimage3"
              className="img-fluid center-img"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Images;

